function greeting(parameterVariable) {
  console.log('Hello, World!');
   console.log(parameterVariable);
}