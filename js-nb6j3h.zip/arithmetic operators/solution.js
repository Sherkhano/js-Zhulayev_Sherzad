function getArea( length, width) {
  let area=length*width;
  
  return area;
}


function getPerimeter(length, width) {
  let perimeter=2*(length+width);
  
  return perimeter;
}