function getCount(objects){
  let ans=0;
  for(let i=0; i<objects.length;i++){
      if(objects[i].x==objects[i].y) ans++;
  }
  return ans;
}