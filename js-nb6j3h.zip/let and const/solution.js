function main() {
  
  const PI=Math.PI;
  
  let r=readLine();
  
console.log(PI*r*r);
console.log(2*PI*r);
  try {....... 