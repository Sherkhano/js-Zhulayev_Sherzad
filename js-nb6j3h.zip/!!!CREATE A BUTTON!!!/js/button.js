var i=1;

function increment(){
    let btn=document.getElementById("btn");
btn.innerHTML=i;
i++;
}